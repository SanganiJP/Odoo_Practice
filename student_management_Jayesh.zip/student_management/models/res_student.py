# -*- coding: utf-8 -*-
from datetime import date, timedelta

from dateutil.relativedelta import relativedelta

from odoo import models, fields, api
from odoo.exceptions import UserError


class   ResStudent(models.Model):
    _name = 'res.student'
    _description = 'student_management.student_management'

    name = fields.Char(string="Name", requried=True)
    registration_id = fields.Char(string="Registration ID",copy=False, readonly=True, index=True, default="New")
    registration_date = fields.Date(string="Registration Date", requried=True)
    date_of_birth = fields.Date(string="Birth Date", requried=True)
    student_age = fields.Char(string="Age",compute="_compute_student_age", store=True)
    phone = fields.Char(string="Phone No")
    email_id = fields.Char(string="Email")
    guardian_name = fields.Char(string="Guardian Name")
    guardian_phone = fields.Char(string="guardian_phone")
    # tuition_fee_structure = fields.Many2one("",string="Tuition Fee Structure")
    is_blocked = fields.Boolean(string="Is Blocked")
    is_expired = fields.Boolean(string="Is Expired")
    previous_year_marks = fields.One2many("previous.year.mark","subject_name",string="Previous year mark")
    tuition_free_structure = fields.Many2one("tuition.fee.structure", string="Tuition free structure")

    @api.model_create_multi
    def create(self, val_list):
        res = super(ResStudent, self).create(val_list)
        for record in res:
            record.registration_id = self.env["ir.sequence"].next_by_code('res.student')
        return res

    @api.depends('date_of_birth')
    def _compute_student_age(self):
        for rec in self:
            if rec.date_of_birth:
                today = date.today()
                difference = relativedelta(today, self.date_of_birth)
                rec.student_age = f'{difference.years}Years, {difference.months}Months'

    @api.constrains('phone')
    def validate_phone(self):
        for record in self:
            if record.phone and len(record.phone) != 10:
                raise UserError("Phone number should be 10 digits.")

            if record.phone:
                patient_ids = self.env['res.student'].search_count([('phone', '=', record.phone)])
                if patient_ids > 1:
                    raise UserError("Phone number already exist.")
                
    def action_unblock_student(self):
        pass
    
    def action_block_student(self):
        pass

    def _schedule_action(self):
        start_of_month = date.today() - timedelta(days=30)

        students = self.env["res.student"].search([
            ('registration_date', '<', start_of_month),
            ('is_blocked','=',True)
        ])

        students.write({'is_expired': True})
