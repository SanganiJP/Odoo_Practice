# -*- coding: utf-8 -*-

from odoo import models, fields, api

class TuitionFeeStructure(models.Model):
    _name = 'tuition.fee.structure'
    _description = 'student_management.tuition.fee.structure'

    product_name = fields.Many2one("product.template",string="Product")
    fee_amount = fields.Float(string="Fee Amount")
    quantity = fields.Float(string="Quantity")
    discount = fields.Float(string="Discount(%)")
    subtotal = fields.Float(string="Fees to pay",compute="_compute_subtotal", store=True)
    total = fields.Float(string="Fees",compute="_compute_total", store=True)

    @api.depends(  'discount', 'total')
    def _compute_subtotal(self):
        for rec in self:
            if rec.product_name:
                rec.subtotal = rec.total - ((rec.total/100)*rec.discount)

    @api.depends('quantity','fee_amount')
    def _compute_total(self):
        for rec in self:
            if rec.product_name:
                rec.total = rec.product_name.fee_amount * rec.quantity








